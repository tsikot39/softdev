let products = [];
let prices = [];
let cart = [];

const enteredProducts = new Set();

// admin section - adding new product
function new_product() {
  const product_input = document.getElementById("product");
  const product = product_input.value.trim();

  if (product === "") {
    alert("Please enter a product name.");
  } else if (enteredProducts.has(product)) {
    alert("Product already exist! Please add another product.");
    document.getElementById("product").value = "";
  } else {
    const product = document.getElementById("product").value;
    if (product) {
      products.push(product);
      update_product();
    }
    enteredProducts.add(product);
    document.getElementById("product").value = "";
    document.getElementById("selectproduct").value = "";
  }
}

// admin section - update product dropdown
function update_product() {
  const select_product = document.getElementById("selectproduct");
  select_product.innerHTML = "";

  products.forEach((product) => {
    const option = document.createElement("option");
    option.value = product;
    option.text = product;
    select_product.add(option);
  });
}

// admin section - add price to product
function add_price() {
  const selected_product = document.getElementById("selectproduct").value;
  const price = document.getElementById("price").value;

  if (selected_product && !isNaN(price)) {
    prices[selected_product] = parseFloat(price);

    const optionCheckout = document.createElement("option");
    optionCheckout.value = `${selected_product} - $${price}/unit`;
    optionCheckout.text = `${selected_product} - $${price}/unit`;
    document.getElementById("checkout_product").add(optionCheckout);
  }
  document.getElementById("selectproduct").value = "";
  document.getElementById("price").value = "";
}

// checkout section - new transaction
function new_transaction() {
  cart = [];
  update_cart();
  document.getElementById("current_date").innerHTML = "";
  document.getElementById("current_time").innerHTML = "";
  document.getElementById("total_price").innerHTML = "";
  document.getElementById("tax").innerHTML = "";
  document.getElementById("amount_due").innerHTML = "";
}

// checkout section - populate cart
function populate_cart() {
  const unit = parseInt(document.getElementById("unit").value);
  add_to_cart(unit);
}

// checkout section - add to cart
function add_to_cart(unit) {
  const selected_product = document.getElementById("checkout_product").value;
  if (selected_product) {
    const price = prices[selected_product.split(" - ")[0]] || 0;
    const total = price * unit;
    const item = {
      product: selected_product,
      price: price,
      unit: unit,
      total: total,
    };
    cart.push(item);
    update_cart();
  }
}

// update cart
function update_cart() {
  const tblReceipt = document.getElementById("tbl_receipt");
  const unit = document.getElementById("unit");
  const cartList = document.getElementById("cart_list");
  unit.value = cart.length > 0 ? cart.length : "";
  cartList.innerHTML = "";

  cart.forEach((item) => {
    const row = tblReceipt.insertRow();
    row.insertCell(0).textContent = item.product;
    row.insertCell(1).textContent = `$${item.price.toFixed(2)}`;
    row.insertCell(2).textContent = item.unit;
    row.insertCell(3).textContent = `$${item.total.toFixed(2)}`;
    cartList.appendChild(row);
  });

  // display current date
  let today = new Date();
  const dd = String(today.getDate()).padStart(2, "0");
  const mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
  const yyyy = today.getFullYear();
  today = mm + "/" + dd + "/" + yyyy;
  document.getElementById("current_date").innerHTML = today;

  // display current time
  let d = new Date();
  const t = d.toLocaleTimeString();
  document.getElementById("current_time").innerHTML = t;

  // total price
  let total_price = 0;
  cart.forEach((item) => {
    total_price += item.total;
    document.getElementById("total_price").innerHTML = `$${total_price.toFixed(
      2
    )}`;

    // tax
    let total_amount = 0;
    cart.forEach((item) => {
      total_amount += item.total;
      const tax = total_amount * 0.05;
      document.getElementById("tax").innerHTML = `$${tax.toFixed(2)}`;
    });

    // amount due
    let amount_due = 0;
    cart.forEach((item) => {
      amount_due += item.total;
    });
    const tax = amount_due * 0.05;
    amount_due += tax;
    document.getElementById("amount_due").innerHTML = `$${amount_due.toFixed(
      2
    )}`;
  });

  document.getElementById("checkout_product").value = "";
  document.getElementById("unit").value = "";
}

// number buttons
function dis(val) {
  unit = document.getElementById("unit").value += val;
}

// pay button
function pay() {
  alert("Thank you for your purchase! Please wait for your receipt.");
  new_transaction();
}
